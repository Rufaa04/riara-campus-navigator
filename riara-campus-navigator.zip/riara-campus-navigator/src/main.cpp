// =============================================================================
//  Riara Campus Navigator
//  Graphs + Dijkstra's algorithm + Trie-based search  (C++17)
//
//  School of Computing Sciences, Riara University
//  CAT 3 - Data Structures and Algorithms
//
//  Data structures and algorithms (see Table 1 of the report)
//    Graph (adjacency list)   vector<vector<pair<int,int>>>   space O(V + E)
//    Dijkstra + min-heap      priority_queue                  O((V + E) log V)
//    Trie                     prefix search / autocomplete    O(L) per search
//    Hash map                 unordered_map<string,int>       O(1) average
//    Route                    vector<int>                     O(V)
//    Linear search            baseline for the trie           O(n * L)
//
//  Usage
//    navigator                        start the web app on http://localhost:8080
//    navigator --port 9000            start the web app on another port
//    navigator --route "Main Gate" "School of Computing Sciences"
//    navigator --verify               Dijkstra vs Floyd-Warshall (Table 3 + all pairs)
//    navigator --benchmark            Trie vs linear search (Table 4)
// =============================================================================

#include "httplib.h"

#include <algorithm>
#include <chrono>
#include <climits>
#include <cmath>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <queue>
#include <random>
#include <sstream>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;

static const int    INF               = INT_MAX / 2;
static const double WALKING_SPEED_MPS = 1.2;   // average walking speed (m/s)

// -----------------------------------------------------------------------------
//  Text helpers
// -----------------------------------------------------------------------------

// Lower-case, trim and collapse repeated spaces so "  LECTURE   hall a " == "lecture hall a".
// The space stays a normal character (challenge 3 in the report).
static string normalize(const string& s) {
    string out;
    bool pendingSpace = false;
    for (unsigned char ch : s) {
        if (ch == ' ' || ch == '\t' || ch == '\r' || ch == '\n') {
            pendingSpace = !out.empty();
        } else {
            if (pendingSpace) { out += ' '; pendingSpace = false; }
            out += static_cast<char>(tolower(ch));
        }
    }
    return out;
}

static string jsonEscape(const string& s) {
    string o;
    for (unsigned char c : s) {
        switch (c) {
            case '"':  o += "\\\""; break;
            case '\\': o += "\\\\"; break;
            case '\n': o += "\\n";  break;
            case '\r': o += "\\r";  break;
            case '\t': o += "\\t";  break;
            default:
                if (c < 0x20) { char b[8]; snprintf(b, sizeof b, "\\u%04x", c); o += b; }
                else o += static_cast<char>(c);
        }
    }
    return o;
}

static string timeText(int seconds) {
    int m = seconds / 60, s = seconds % 60;
    ostringstream os;
    if (m > 0) os << m << " min ";
    os << s << " s";
    return os.str();
}

// -----------------------------------------------------------------------------
//  Graph  (adjacency list)
// -----------------------------------------------------------------------------
struct Graph {
    int n = 0;                                   // V: number of locations
    vector<vector<pair<int, int>>> adj;          // adj[u] = list of (v, metres)
    vector<string> names;                        // names[id] = display name
    vector<double> px, py;                       // map coordinates (for the web map)
    unordered_map<string, int> idByName;         // hash map: lower-case name -> node ID
    int edgeCount = 0;                           // E: number of two-way walkways

    void resize(int count) {
        n = count;
        adj.assign(n, {});
        names.assign(n, "");
        px.assign(n, 0);
        py.assign(n, 0);
    }
    // Walking is two-way, so each edge is stored in BOTH directions.
    void addEdge(int a, int b, int metres) {
        adj[a].push_back({b, metres});
        adj[b].push_back({a, metres});
        ++edgeCount;
    }
    int find(const string& name) const {         // -1 if the name is unknown
        auto it = idByName.find(normalize(name));
        return it == idByName.end() ? -1 : it->second;
    }
    int weight(int a, int b) const {
        for (auto& e : adj[a]) if (e.first == b) return e.second;
        return -1;
    }
};

// Reads the text file used for data storage (see data/campus.txt).
static bool loadGraph(const string& file, Graph& g, string& error) {
    ifstream in(file);
    if (!in) { error = "cannot open " + file; return false; }

    struct N { int id; double x, y; string name; };
    struct E { int a, b, w; };
    vector<N> nodes;
    vector<E> edges;

    string line;
    while (getline(in, line)) {
        if (!line.empty() && line.back() == '\r') line.pop_back();
        istringstream ls(line);
        string tag;
        if (!(ls >> tag) || tag[0] == '#') continue;
        if (tag == "NODE") {
            N nd;
            ls >> nd.id >> nd.x >> nd.y;
            getline(ls, nd.name);
            size_t start = nd.name.find_first_not_of(" \t");
            nd.name = (start == string::npos) ? "" : nd.name.substr(start);
            nodes.push_back(nd);
        } else if (tag == "EDGE") {
            E e; ls >> e.a >> e.b >> e.w;
            edges.push_back(e);
        }
    }
    if (nodes.empty()) { error = "no NODE lines found"; return false; }

    g.resize(static_cast<int>(nodes.size()));
    for (auto& nd : nodes) {
        if (nd.id < 0 || nd.id >= g.n) { error = "node IDs must be 0..V-1"; return false; }
        g.names[nd.id] = nd.name;
        g.px[nd.id] = nd.x;
        g.py[nd.id] = nd.y;
        g.idByName[normalize(nd.name)] = nd.id;
    }
    for (auto& e : edges) {
        if (e.a < 0 || e.a >= g.n || e.b < 0 || e.b >= g.n || e.w <= 0) {
            error = "bad EDGE line"; return false;
        }
        g.addEdge(e.a, e.b, e.w);
    }
    return true;
}

// -----------------------------------------------------------------------------
//  Dijkstra's algorithm with a min-heap  (Algorithm 1 in the report)
// -----------------------------------------------------------------------------
struct Route {
    bool found = false;
    int distance = INF;      // metres
    vector<int> path;        // node IDs from source to destination
};

static Route dijkstra(const Graph& g, int source, int destination) {
    vector<int> dist(g.n, INF);                   // dist[v] = infinity
    vector<int> parent(g.n, -1);                  // parent[v] = none
    dist[source] = 0;

    using Entry = pair<int, int>;                 // (distance, node)
    priority_queue<Entry, vector<Entry>, greater<Entry>> pq;   // min-priority queue
    pq.push({0, source});

    while (!pq.empty()) {
        auto [d, u] = pq.top();                   // extractMin
        pq.pop();
        if (u == destination) break;
        if (d > dist[u]) continue;                // outdated queue entry
        for (auto [v, w] : g.adj[u]) {
            if (dist[u] + w < dist[v]) {
                dist[v] = dist[u] + w;
                parent[v] = u;
                pq.push({dist[v], v});
            }
        }
    }

    Route r;
    if (dist[destination] >= INF) return r;       // unreachable
    r.found = true;
    r.distance = dist[destination];
    for (int v = destination; v != -1; v = parent[v]) r.path.push_back(v);
    reverse(r.path.begin(), r.path.end());        // rebuild path from parent[]
    return r;
}

// Independent check: Floyd-Warshall all-pairs shortest distances, O(V^3).
static vector<vector<int>> floydWarshall(const Graph& g) {
    vector<vector<int>> d(g.n, vector<int>(g.n, INF));
    for (int i = 0; i < g.n; ++i) {
        d[i][i] = 0;
        for (auto [j, w] : g.adj[i]) d[i][j] = min(d[i][j], w);
    }
    for (int k = 0; k < g.n; ++k)
        for (int i = 0; i < g.n; ++i)
            for (int j = 0; j < g.n; ++j)
                if (d[i][k] + d[k][j] < d[i][j]) d[i][j] = d[i][k] + d[k][j];
    return d;
}

// -----------------------------------------------------------------------------
//  Trie  (Algorithm 2 in the report)
// -----------------------------------------------------------------------------
class Trie {
    struct Node {
        map<char, int> child;      // ordered, so suggestions come out alphabetically
        int word = -1;             // index into words_ if a name ends here
    };
    vector<Node> nodes_;
    vector<string> words_;         // original (display) names

    void collect(int node, vector<string>& out) const {        // depth-first traversal
        if (nodes_[node].word != -1) out.push_back(words_[nodes_[node].word]);
        for (auto& kv : nodes_[node].child) collect(kv.second, out);
    }

public:
    Trie() { nodes_.emplace_back(); }                           // node 0 = root

    void insert(const string& name) {                           // INSERT(word)
        int cur = 0;
        for (char c : normalize(name)) {
            auto it = nodes_[cur].child.find(c);
            if (it == nodes_[cur].child.end()) {
                nodes_.emplace_back();
                int created = static_cast<int>(nodes_.size()) - 1;
                nodes_[cur].child[c] = created;
                cur = created;
            } else {
                cur = it->second;
            }
        }
        nodes_[cur].word = static_cast<int>(words_.size());     // mark end of word
        words_.push_back(name);
    }

    vector<string> suggest(const string& prefix) const {        // SUGGEST(prefix)
        int cur = 0;
        for (char c : normalize(prefix)) {
            auto it = nodes_[cur].child.find(c);
            if (it == nodes_[cur].child.end()) return {};       // no match
            cur = it->second;
        }
        vector<string> out;
        collect(cur, out);
        return out;
    }
};

// Baseline for the comparison: scan every name and test the prefix, O(n * L).
class LinearSearch {
    vector<string> original_, lower_;
public:
    void insert(const string& name) { original_.push_back(name); lower_.push_back(normalize(name)); }
    vector<string> suggest(const string& prefix) const {
        string p = normalize(prefix);
        vector<string> out;
        for (size_t i = 0; i < lower_.size(); ++i)
            if (lower_[i].compare(0, p.size(), p) == 0) out.push_back(original_[i]);
        sort(out.begin(), out.end(), [](const string& a, const string& b) { return normalize(a) < normalize(b); });
        return out;
    }
};

// Minimum characters before suggestions are returned (objective 3).
static const size_t MIN_PREFIX = 2;

// -----------------------------------------------------------------------------
//  --verify : Dijkstra vs Floyd-Warshall
// -----------------------------------------------------------------------------
static int runVerify(const Graph& g) {
    struct T { const char* a; const char* b; };
    const T tests[] = {
        {"Main Gate", "Library"},
        {"Main Gate", "School of Computing Sciences"},
        {"Main Gate", "Riara Law School"},
        {"Admissions Office", "Computer Lab"},
        {"Registry", "Innovations Centre"},
        {"Cafeteria", "School of Business"},
        {"Campus Garden", "Student Affairs Office"},
        {"Basketball Court", "Lecture Hall A"},
        {"Security Reception", "School of Computing Sciences"},
        {"Administration Block", "Riara Law School"},
        {"Computer Lab", "Basketball Court"},
        {"Library", "Student Affairs Office"},
    };
    auto fw = floydWarshall(g);

    cout << "Graph: " << g.n << " locations, " << g.edgeCount << " walkways\n\n";
    cout << left << setw(5) << "Test" << setw(24) << "Start" << setw(32) << "Destination"
         << setw(16) << "Floyd-Warshall" << setw(10) << "Dijkstra" << "Pass?\n";
    cout << string(95, '-') << "\n";

    int passed = 0, idx = 0;
    for (auto& t : tests) {
        int a = g.find(t.a), b = g.find(t.b);
        int expected = fw[a][b];
        Route r = dijkstra(g, a, b);
        bool ok = r.found && r.distance == expected;
        passed += ok;
        cout << left << setw(5) << ++idx << setw(24) << t.a << setw(32) << t.b
             << setw(16) << (to_string(expected) + " m") << setw(10) << (to_string(r.distance) + " m")
             << (ok ? "Yes" : "NO") << "\n";
    }
    cout << "\nNamed test pairs: " << passed << " / " << idx << " passed ("
         << fixed << setprecision(0) << (100.0 * passed / idx) << "% agreement)\n";

    int pairs = 0, pairOk = 0;
    for (int a = 0; a < g.n; ++a)
        for (int b = 0; b < g.n; ++b) {
            if (a == b) continue;
            ++pairs;
            Route r = dijkstra(g, a, b);
            pairOk += (r.found && r.distance == fw[a][b]);
        }
    cout << "All ordered pairs: " << pairOk << " / " << pairs << " passed\n";
    return (passed == idx && pairOk == pairs) ? 0 : 1;
}

// -----------------------------------------------------------------------------
//  --benchmark : Trie vs linear search
// -----------------------------------------------------------------------------
static vector<string> makeDataset(const Graph& g, size_t size, unsigned seed) {
    // The 16 real names come first; the rest are random but pronounceable names
    // (e.g. "Kobera Lunat") so that prefixes behave like real, varied place names.
    vector<string> names(g.names.begin(), g.names.end());
    static const char* CONS = "bcdfghjklmnprstvwz";
    static const char* VOWL = "aeiou";
    mt19937 rng(seed);
    auto word = [&]() {
        string w;
        int syllables = 2 + static_cast<int>(rng() % 2);
        for (int i = 0; i < syllables; ++i) { w += CONS[rng() % 18]; w += VOWL[rng() % 5]; if (rng() % 3 == 0) w += CONS[rng() % 18]; }
        w[0] = static_cast<char>(toupper(w[0]));
        return w;
    };
    while (names.size() < size) names.push_back(word() + " " + word());
    names.resize(size);
    return names;
}

static void runBenchmark(const Graph& g) {
    const size_t sizes[] = {20, 1000, 10000};
    const int PREFIXES = 200, REPEATS = 50;
    cout << "Prefix search benchmark: " << PREFIXES << " prefixes x " << REPEATS
         << " repeats per dataset (average time per search)\n\n";
    cout << left << setw(14) << "Dataset size" << setw(20) << "Linear search (us)" << setw(14) << "Trie (us)"
         << "Speed-up\n" << string(60, '-') << "\n";

    for (size_t size : sizes) {
        vector<string> names = makeDataset(g, size, 12345);
        Trie trie; LinearSearch lin;
        for (auto& n : names) { trie.insert(n); lin.insert(n); }

        mt19937 rng(777);
        vector<string> prefixes;
        for (int i = 0; i < PREFIXES; ++i) {
            const string& nm = names[rng() % names.size()];
            size_t len = 2 + rng() % 4;                       // 2..5 characters
            prefixes.push_back(nm.substr(0, min(len, nm.size())));
        }

        static size_t sink = 0;                               // stops the compiler removing the work
        auto time = [&](auto& index) {
            auto t0 = chrono::steady_clock::now();
            for (int r = 0; r < REPEATS; ++r)
                for (auto& p : prefixes) sink += index.suggest(p).size();
            auto t1 = chrono::steady_clock::now();
            return chrono::duration<double, micro>(t1 - t0).count() / (PREFIXES * REPEATS);
        };
        double tl = time(lin), tt = time(trie);

        cout << left << setw(14) << size << setw(20) << fixed << setprecision(2) << tl
             << setw(14) << tt << setprecision(1) << (tl / tt) << "x\n";
    }
    cout << "\nNote: absolute times depend on your computer; the trend is what matters.\n";
}

// -----------------------------------------------------------------------------
//  Web API
// -----------------------------------------------------------------------------
struct RouteJson { bool ok; string body; };

static RouteJson routeToJson(const Graph& g, const string& from, const string& to) {
    int a = g.find(from), b = g.find(to);
    if (a < 0) return {false, "{\"ok\":false,\"error\":\"Unknown start location: " + jsonEscape(from) + "\"}"};
    if (b < 0) return {false, "{\"ok\":false,\"error\":\"Unknown destination: " + jsonEscape(to) + "\"}"};

    Route r = dijkstra(g, a, b);
    if (!r.found) return {false, "{\"ok\":false,\"error\":\"No walking route found\"}"};

    int seconds = static_cast<int>(lround(r.distance / WALKING_SPEED_MPS));
    ostringstream js;
    js << "{\"ok\":true,\"distance\":" << r.distance
       << ",\"seconds\":" << seconds
       << ",\"time_text\":\"" << timeText(seconds) << "\",\"path\":[";
    for (size_t i = 0; i < r.path.size(); ++i) {
        if (i) js << ',';
        js << "{\"id\":" << r.path[i] << ",\"name\":\"" << jsonEscape(g.names[r.path[i]]) << "\"}";
    }
    js << "],\"steps\":[";
    for (size_t i = 0; i + 1 < r.path.size(); ++i) {
        if (i) js << ',';
        js << "{\"from\":\"" << jsonEscape(g.names[r.path[i]]) << "\",\"to\":\"" << jsonEscape(g.names[r.path[i + 1]])
           << "\",\"metres\":" << g.weight(r.path[i], r.path[i + 1]) << "}";
    }
    js << "]}";
    return {true, js.str()};
}

static string graphToJson(const Graph& g) {
    ostringstream js;
    js << "{\"nodes\":[";
    for (int i = 0; i < g.n; ++i) {
        if (i) js << ',';
        js << "{\"id\":" << i << ",\"name\":\"" << jsonEscape(g.names[i]) << "\",\"x\":" << g.px[i] << ",\"y\":" << g.py[i] << "}";
    }
    js << "],\"edges\":[";
    bool first = true;
    for (int u = 0; u < g.n; ++u)
        for (auto [v, w] : g.adj[u])
            if (u < v) {                                         // each two-way walkway once
                if (!first) js << ',';
                first = false;
                js << "{\"a\":" << u << ",\"b\":" << v << ",\"w\":" << w << "}";
            }
    js << "],\"speed\":" << WALKING_SPEED_MPS << "}";
    return js.str();
}

// Look for a folder next to where the program is started (works from the project
// folder or from a build sub-folder such as bin/Debug).
static string findDir(const string& name) {
    const string tries[] = {"./" + name, "../" + name, "../../" + name, "../../../" + name};
    for (auto& t : tries) {
        ifstream probe(t + (name == "data" ? "/campus.txt" : "/index.html"));
        if (probe) return t;
    }
    return "";
}

static int runServer(const Graph& g, const Trie& trie, const string& webDir, int port) {
    httplib::Server svr;
    if (!svr.set_mount_point("/", webDir)) {
        cerr << "Could not serve web folder: " << webDir << "\n";
        return 1;
    }

    svr.Get("/api/graph", [&](const httplib::Request&, httplib::Response& res) {
        res.set_content(graphToJson(g), "application/json");
    });

    svr.Get("/api/suggest", [&](const httplib::Request& req, httplib::Response& res) {
        string q = req.has_param("q") ? req.get_param_value("q") : "";
        vector<string> out;
        double micros = 0;
        if (normalize(q).size() >= MIN_PREFIX) {
            auto t0 = chrono::steady_clock::now();
            out = trie.suggest(q);
            micros = chrono::duration<double, micro>(chrono::steady_clock::now() - t0).count();
        }
        ostringstream js;
        js << "{\"query\":\"" << jsonEscape(q) << "\",\"micros\":" << fixed << setprecision(1) << micros << ",\"suggestions\":[";
        for (size_t i = 0; i < out.size(); ++i) js << (i ? "," : "") << "\"" << jsonEscape(out[i]) << "\"";
        js << "]}";
        res.set_content(js.str(), "application/json");
    });

    svr.Get("/api/route", [&](const httplib::Request& req, httplib::Response& res) {
        string from = req.has_param("from") ? req.get_param_value("from") : "";
        string to   = req.has_param("to")   ? req.get_param_value("to")   : "";
        RouteJson r = routeToJson(g, from, to);
        if (!r.ok) res.status = 400;
        res.set_content(r.body, "application/json");
    });

    cout << "Riara Campus Navigator is running.\n"
         << "Open  http://localhost:" << port << "  in Google Chrome (press Ctrl+C to stop).\n";
    if (!svr.listen("127.0.0.1", port)) {
        cerr << "Could not start the server on port " << port << " (is it already in use? try --port 9000)\n";
        return 1;
    }
    return 0;
}

// -----------------------------------------------------------------------------
//  main
// -----------------------------------------------------------------------------
int main(int argc, char** argv) {
    string dataDir = findDir("data");
    if (dataDir.empty()) {
        cerr << "Cannot find data/campus.txt - run the program from the project folder.\n";
        return 1;
    }
    Graph g;
    string error;
    if (!loadGraph(dataDir + "/campus.txt", g, error)) {
        cerr << "Data error: " << error << "\n";
        return 1;
    }
    Trie trie;
    for (auto& name : g.names) trie.insert(name);

    string mode = argc > 1 ? argv[1] : "";
    if (mode == "--verify")    return runVerify(g);
    if (mode == "--benchmark") { runBenchmark(g); return 0; }
    if (mode == "--route") {
        if (argc < 4) { cerr << "Usage: navigator --route \"Start\" \"Destination\"\n"; return 1; }
        int a = g.find(argv[2]), b = g.find(argv[3]);
        if (a < 0 || b < 0) { cerr << "Unknown location.\n"; return 1; }
        Route r = dijkstra(g, a, b);
        int sec = static_cast<int>(lround(r.distance / WALKING_SPEED_MPS));
        cout << "Shortest route: " << r.distance << " m | Estimated walking time: " << timeText(sec) << "\n";
        for (size_t i = 0; i < r.path.size(); ++i) {
            cout << (i ? " -> " : "") << g.names[r.path[i]];
        }
        cout << "\n";
        return 0;
    }

    int port = 8080;
    if (mode == "--port" && argc > 2) port = atoi(argv[2]);

    string webDir = findDir("web");
    if (webDir.empty()) { cerr << "Cannot find web/index.html - run the program from the project folder.\n"; return 1; }
    cout << "Loaded " << g.n << " locations and " << g.edgeCount << " walkways.\n";
    return runServer(g, trie, webDir, port);
}
